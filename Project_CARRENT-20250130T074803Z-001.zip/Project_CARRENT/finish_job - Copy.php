<?php
include 'db.php';


if (isset($_GET['booking_id'])) {
    $booking_id = $_GET['booking_id'];


    $conn->begin_transaction();

    try {

        $sql = "UPDATE bookings SET status = 'finished' WHERE id = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("i", $booking_id);
            if (!$stmt->execute()) {
                throw new Exception("Error updating booking status: " . $stmt->error);
            }
            $stmt->close();
        } else {
            throw new Exception("Error preparing statement: " . $conn->error);
        }


        $sql = "SELECT car_id FROM bookings WHERE id = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("i", $booking_id);
            $stmt->execute();
            $stmt->bind_result($car_id);
            $stmt->fetch();
            $stmt->close();
        } else {
            throw new Exception("Error preparing statement: " . $conn->error);
        }


        $sql = "UPDATE cars SET available = 1 WHERE id = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("i", $car_id);
            if (!$stmt->execute()) {
                throw new Exception("Error updating car availability: " . $stmt->error);
            }
            $stmt->close();
        } else {
            throw new Exception("Error preparing statement: " . $conn->error);
        }


        $conn->commit();


        header("Location: driver_jobs.php?message=Job marked as finished.");
        exit;
    } catch (Exception $e) {

        $conn->rollback();
        echo $e->getMessage();
    }
} else {
    echo "Invalid request.";
}

$conn->close();
?>
