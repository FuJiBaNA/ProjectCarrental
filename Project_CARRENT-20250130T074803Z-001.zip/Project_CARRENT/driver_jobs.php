<?php
session_start();
if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit;
}

include 'db.php';


$sql = "SELECT bookings.id, cars.make, cars.model, bookings.pickup_date, bookings.return_date, locations_pickup.name AS pickup_location, locations_return.name AS return_location 
        FROM bookings 
        JOIN cars ON bookings.car_id = cars.id 
        JOIN locations AS locations_pickup ON bookings.pickup_location = locations_pickup.id
        JOIN locations AS locations_return ON bookings.return_location = locations_return.id
        WHERE bookings.status = 'active'"; 

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Jobs</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Driver Jobs</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="driver_jobs.php">My Jobs</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section id="job-list">
            <h2>Current Jobs</h2>
            <?php if ($result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Car</th>
                            <th>Pickup Location</th>
                            <th>Return Location</th>
                            <th>Pickup Date</th>
                            <th>Return Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['make'] . ' ' . $row['model']); ?></td>
                                <td><?php echo htmlspecialchars($row['pickup_location']); ?></td>
                                <td><?php echo htmlspecialchars($row['return_location']); ?></td>
                                <td><?php echo htmlspecialchars($row['pickup_date']); ?></td>
                                <td><?php echo htmlspecialchars($row['return_date']); ?></td>
                                <td><a href="finish_job.php?booking_id=<?php echo $row['id']; ?>" class="btn">Mark as Finished</a></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No current jobs.</p>
            <?php endif; ?>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 XYZ Car Rentals. All rights reserved.</p>
    </footer>
</body>
</html>

<?php $conn->close(); ?>
