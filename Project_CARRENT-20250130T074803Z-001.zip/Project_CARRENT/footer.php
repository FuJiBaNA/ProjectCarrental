<footer>
        <p>&copy; 2024 Car Rentals. All rights reserved FOR PROJECT.</p>
    </footer>
</body>
</html>