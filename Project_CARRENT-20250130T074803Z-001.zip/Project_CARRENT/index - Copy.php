<?php include 'head.php'; ?>

    <main>
        <section id="intro">
            <h2>ยินดีต้อนรับสู่ระบบเช่ารถ</h2>
        </section>
        <section id="services">
            <h2>บริการของเรา</h2>
            <ul>
                <li><a href="book.php">เช่ารายวัน</a></li>
                <li><a href="book.php">เช่ารายสัปดาห์</a></li>
                <li><a href="book.php">เช่ารายเดือน</a></li>
            </ul>
        </section>
    </main>
    
</body>
<?php include 'footer.php'; ?>
