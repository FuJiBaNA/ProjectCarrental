<?php
include 'db.php';

$username = 'test'; 
$password = 'test'; 
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

$sql = "INSERT INTO drivers (username, password) VALUES (?, ?)";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("ss", $username, $hashed_password);
    if ($stmt->execute()) {
        echo "Driver registered successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Error preparing statement: " . $conn->error;
}

$conn->close();
?>
