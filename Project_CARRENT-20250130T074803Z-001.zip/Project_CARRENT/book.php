<?php include 'db.php'; ?>
<?php include 'head.php'; ?>


    <main>
        <section id="booking-form">
            <h2>ลงทะเบียนเช่ารถ</h2>
            <form action="process_booking.php" method="post">
                <div class="form-group">
                    <label for="car">Select Car:<   /label>
                    <select name="car_id" id="car" required>
                        <?php
                        $sql = "SELECT id, make, model, year FROM cars WHERE available = 1";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row["id"] . "'>" . $row["make"] . " " . $row["model"] . " (" . $row["year"] . ")</option>";
                            }
                        } else {
                            echo "<option value=''>No cars available</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pickup">Pickup Location:</label>
                    <select name="pickup_location" id="pickup" required>
                        <?php
                        $sql = "SELECT id, name FROM locations";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row["id"] . "'>" . $row["name"] . "</option>";
                            }
                        } else {
                            echo "<option value=''>No locations available</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="return">Return Location:</label>
                    <select name="return_location" id="return" required>
                        <?php
                        $sql = "SELECT id, name FROM locations";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row["id"] . "'>" . $row["name"] . "</option>";
                            }
                        } else {
                            echo "<option value=''>No locations available</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pickup-date">Pickup Date:</label>
                    <input type="date" name="pickup_date" id="pickup-date" required>
                </div>
                <div class="form-group">
                    <label for="return-date">Return Date:</label>
                    <input type="date" name="return_date" id="return-date" required>
                </div>
                <div class="form-group">
                    <label for="name">Your Name:</label>
                    <input type="text" name="name" id="name" required>
                </div>
                <div class="form-group">
                    <label for="email">Your Email:</label>
                    <input type="email" name="email" id="email" required>
                </div>
                <div class="form-group">
                    <label for="phone">Your Phone:</label>
                    <input type="tel" name="phone" id="phone" required>
                </div>
                <button type="submit" class="btn">เช่ารถเลยทันที</button>
            </form>
        </section>
    </main>
    <?php include 'footer.php'; ?>
