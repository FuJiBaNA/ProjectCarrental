<?php include 'db.php'; ?>
<?php include 'head.php'; ?>

    <main>
        <section id="car-list">
            <h2>Available Cars</h2>
            <div class="car-container">
                <?php
                $sql = "SELECT id, make, model, year, price, image FROM cars WHERE available = 1";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<div class='car-card'>";
                        echo "<img src='images/" . $row["image"] . "' alt='" . $row["make"] . " " . $row["model"] . "'>";
                        echo "<div class='car-info'>";
                        echo "<h3>" . $row["make"] . " " . $row["model"] . " (" . $row["year"] . ")</h3>";
                        echo "<p>$" . $row["price"] . " per day</p>";
                        echo "<a href='book.php?car_id=" . $row["id"] . "' class='btn'>ลงทะเบียนเช่ารถ</a>";
                        echo "</div>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>No cars available</p>";
                }
                $conn->close();
                ?>
            </div>
        </section>
    </main>
    <?php include 'footer.php'; ?>
