<?php
include 'db.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $car_id = $_POST['car_id'];
    $pickup_location_id = $_POST['pickup_location'];
    $return_location_id = $_POST['return_location'];
    $pickup_date = $_POST['pickup_date'];
    $return_date = $_POST['return_date'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // Validate form data (basic validation example)
    if (empty($car_id) || empty($pickup_location_id) || empty($return_location_id) || empty($pickup_date) || empty($return_date) || empty($name) || empty($email) || empty($phone)) {
        header("Location: error.php?message=All fields are required.");
        exit;
    }

    // Retrieve location names
    $pickup_location_name = "";
    $return_location_name = "";

    $location_sql = "SELECT id, name FROM locations WHERE id IN (?, ?)";
    if ($stmt = $conn->prepare($location_sql)) {
        $stmt->bind_param("ii", $pickup_location_id, $return_location_id);
        $stmt->execute();
        $stmt->bind_result($location_id, $location_name);

        while ($stmt->fetch()) {
            if ($location_id == $pickup_location_id) {
                $pickup_location_name = $location_name;
            } elseif ($location_id == $return_location_id) {
                $return_location_name = $location_name;
            }
        }
        $stmt->close();
    }

    // Insert booking into the database
    $sql = "INSERT INTO bookings (car_id, pickup_location, return_location, pickup_date, return_date, name, email, phone) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("iissssss", $car_id, $pickup_location_id, $return_location_id, $pickup_date, $return_date, $name, $email, $phone);

        if ($stmt->execute()) {
            // Update car availability
            $update_sql = "UPDATE cars SET available = 0 WHERE id = ?";
            if ($update_stmt = $conn->prepare($update_sql)) {
                $update_stmt->bind_param("i", $car_id);
                $update_stmt->execute();
            }

            // Retrieve car details for success message
            $car_sql = "SELECT make, model FROM cars WHERE id = ?";
            if ($car_stmt = $conn->prepare($car_sql)) {
                $car_stmt->bind_param("i", $car_id);
                $car_stmt->execute();
                $car_stmt->bind_result($make, $model);
                $car_stmt->fetch();
                $car_stmt->close();
            }

            // Redirect to success page with booking details
            $url = "success.php?" . http_build_query([
                'car' => $make . ' ' . $model,
                'pickup_location' => $pickup_location_name,
                'return_location' => $return_location_name,
                'pickup_date' => $pickup_date,
                'return_date' => $return_date,
                'name' => $name,
                'email' => $email,
                'phone' => $phone
            ]);
            header("Location: $url");
            exit;
        } else {
            header("Location: error.php?message=" . urlencode($stmt->error));
            exit;
        }

        $stmt->close();
    } else {
        header("Location: error.php?message=" . urlencode($conn->error));
        exit;
    }

    $conn->close();
} else {
    header("Location: error.php?message=Invalid request.");
    exit;
}
?>
