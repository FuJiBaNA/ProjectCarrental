<?php include 'db.php'; ?>
<?php include 'head.php'; ?>
<body>
    <main>
        <section id="success-message">
            <h2>Thank You for Your Booking!</h2>
            <p>Your booking has been successfully processed. Here are your booking details:</p>
            <ul>
                <li><strong>Car:</strong> <?php echo htmlspecialchars($_GET['car']); ?></li>
                <li><strong>Pickup Location:</strong> <?php echo htmlspecialchars($_GET['pickup_location']); ?></li>
                <li><strong>Return Location:</strong> <?php echo htmlspecialchars($_GET['return_location']); ?></li>
                <li><strong>Pickup Date:</strong> <?php echo htmlspecialchars($_GET['pickup_date']); ?></li>
                <li><strong>Return Date:</strong> <?php echo htmlspecialchars($_GET['return_date']); ?></li>
                <li><strong>Name:</strong> <?php echo htmlspecialchars($_GET['name']); ?></li>
                <li><strong>Email:</strong> <?php echo htmlspecialchars($_GET['email']); ?></li>
                <li><strong>Phone:</strong> <?php echo htmlspecialchars($_GET['phone']); ?></li>
            </ul>
            <p>If you have any questions, please contact us at <a href="mailto:support@example.com">support@example.com</a>.</p>
        </section>
    </main>
    <?php include 'footer.php'; ?>